== Changelog ==

= 1.0.4 = Released on Apr 13, 2016

* Added: Added minimized js files. Plugin loads full files version if the constant "SCRIPT_DEBUG" is defined and is true.
* Added: Compatibility with YITH WooCommerce Waiting List
* Added: Compatibility with WordPress 4.5
* Fixed: Option "Enable Popup" for archive page.
* Fixed: Rsponsive style.
* Updated: Change all frontend ajax call from admin-ajax to wc-ajax.
* Updated: Plugin Core
* Updated: Language file

= 1.0.3 = Released on Dec 28, 2015

* Added: Compatibility with Wordpress 4.4
* Added: Compatibility with WooCommerce 2.5 BETA 3
* Added: Option to show selected variation on popup
* Added: XML config file for WPML
* Added: Compatibility with Gravity Form Product Addons Plugin
* Fixed: Popup dimension on mobile device
* Updated: Plugin Core
* Updated: Language file

= 1.0.2 = Released on Aug 13, 2015

* Added: Compatibility with WooCommerce 2.4
* Updated: Plugin Core
* Updated: Language file

= 1.0.1 = Released on Jul 27, 2015

* Initial release